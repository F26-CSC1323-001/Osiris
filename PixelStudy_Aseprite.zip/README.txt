PIXEL STUDY GAME - ASEPRITE FILES
=================================

Every file opens directly in Aseprite (checked with Aseprite 1.3.18). Each one has a single
layer called "Sprite", frames lined up on the character's feet, and one tag per animation
(the same names the game uses), with the game's frame timings.

Enemies/
  One file per enemy, every animation as a tag (walk, tell, charge, ...):
  Beetle, Wasp, AcidTick, PillBug, TermiteGuard, Scorpion, FireflyBomber, StagBeetle,
  Spiderling, BroodMother, HornetQueen, ReaperMantis, SilkWidow, InfestedKnight, Parasite.
  Enemies/Attacks/<boss>/  the bosses' projectiles and effects (acid, rocks, stingers,
  scythe wave, moon, silk, webs, cocoon, the Infested Knight's violet fire).

Knight/
  Only the moves that weren't in the original Knight_1 sheets.
  Knight_AllNewMoves.aseprite  every new move in one file, one tag each.
  Moves/<move>.aseprite        the same moves, one file each.
  Notes:
  - These moves are built from frames of the original Knight_1 sheets, re-ordered and
    combined (for example slash2 mixes Run+Attack and Attack 2 frames).
  - roll: in the game it's one tucked frame spun by code; the spin is baked into 10 frames here.
  - drink: the flask (a separate sprite in the game) is drawn into the frame.

Skills/
  Effects for each knight skill, grouped by skill (Sword, OverheadSlash, FlameSlash,
  ThousandCuts, ArcaneOrbs, Thunder, Heavenfall, Flask) and the HUD icons in Skills/Icons.
  The magic circle in ArcaneOrbs is also Riposte's ward and Heavenfall's sky sigil.
  Effects are animated by code in the game (scale, spin, fade), so the multi-frame ones are set
  to 12 fps here as a starting point.

contents.txt lists every file with its canvas size, frame count and tags.
